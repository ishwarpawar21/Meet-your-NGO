<?php

$this->load->view('front-header',$page_title);

$this->load->view($middle_content);

$this->load->view('front-footer');

?>