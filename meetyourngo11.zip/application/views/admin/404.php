<div id="main_container"><!-- style="min-height:400px;"-->
<div class="work_area" style="text-align:center;margin-top:120px;margin-bottom:150px;">
<a href="javascript:history.go(-1)"  style="text-decoration:none;" >
<img src="<?php echo base_url();?>images/404-page.png" height="400" width="500" /> 
</a>
</div>
<div class="clr"></div>
</div>                        
<!-- end of main container -->                       
