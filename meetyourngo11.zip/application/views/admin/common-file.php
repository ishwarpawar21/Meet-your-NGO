<?php
$this->load->view('admin/admin-header',$pagetitle);
$this->load->view('admin/'.$middle_content);
$this->load->view('admin/admin-footer');
?>