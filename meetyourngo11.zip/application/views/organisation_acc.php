<div class="container">
	<div class="main">
		<div class="content" style="text-align: left">
			<div class="col-md-12" style="margin: 10px">
				<div class="col-md-3">
					<div class="w_nav1">
						<ul>
							<li><a href="<?=base_url()?>organisation_acc?ch=admin_profile">Edit Administrator Profile</a></li>
							<li><a href="<?=base_url()?>organisation_acc?ch=org_profile">Edit Organisation Profile</a></li>
							<li><a href="<?=base_url()?>organisation_acc?ch=change_pass">Change Password</a></li>
							<li><a href="<?=base_url()?>organisation_acc?ch=logout">Logout</a></li>
							
						</ul>	
					</div>
				</div>
				<div class="col-md-9">
				
<?php
	if(isset($_GET['ch']))
	{
			if($_GET['ch']=="admin_profile")
			{
				if(isset($_POST['update_org_admin']))
			    {
				
				
				$this->form_validation->set_rules('v_fname','first name','required|xss_clean');
				$this->form_validation->set_rules('v_lname','last name','required|xss_clean');
				
				$this->form_validation->set_rules('v_mob_no','mobile','required|xss_clean');
				 if($this->form_validation->run())
			  	  { 
				 
                   $data=array(
				    	'o_fname'=>$this->input->post('v_fname'),
                        'o_lname'=>$this->input->post('v_lname'),
                      
                        'o_mob'=>$this->input->post('v_mob_no'),
					);
                    $this->load->model('site_model');
					$result=$this->site_model->update('organisation',$data,$this->input->post('id'));
					if($result)
					{
					   $this->session->set_userdata('error_msg','Profile Updated Successfully');
                       $this->session->set_userdata('error_cls','success');
					   
					}
                    else
                    {
                        
					   $this->session->set_userdata('error_msg','Error occurred, Try again...');
                       $this->session->set_userdata('error_cls','danger');
                    }
                    redirect(base_url().'organisation_acc?ch=admin_profile');
					
				  }
			   }
                
                
                $this->load->view('organisation/update_administration_profile');
			}else
			if($_GET['ch']=="org_profile")
			{
			   	if(isset($_POST['update_org']))
			    {
				
				
				$this->form_validation->set_rules('o_name_of_org','Orgnization name','required|xss_clean');
				$this->form_validation->set_rules('o_org_email','email','required|xss_clean');
                $this->form_validation->set_rules('o_address','area','required|xss_clean');
				//$this->form_validation->set_rules('o_state','state','required|xss_clean');
			    //$this->form_validation->set_rules('o_city','city','required|xss_clean');
   	            $this->form_validation->set_rules('o_pin_code','pin code','required|xss_clean');
				$this->form_validation->set_rules('o_org_phone','phone','required|xss_clean');
			
				 if($this->form_validation->run())
			  	  { 
				 
					$data=array(
				    	'o_name_of_org'=>$this->input->post('o_name_of_org'),
                        'o_org_email'=>$this->input->post('o_org_email'),
                        'o_address'=>$this->input->post('o_address'),
                       	'o_state'=>$this->input->post('o_state'),
                        'o_city'=>$this->input->post('o_city'),
                        'o_pin_code'=>$this->input->post('o_pin_code'),
                       	'o_org_phone'=>$this->input->post('o_org_phone')
                        
					);
                    $this->load->model('site_model');
					$result=$this->site_model->update('organisation',$data,$this->input->post('id'));
					echo $result;
                    
                    if($result)
					{
					   $this->session->set_userdata('error_msg','Profile Updated Successfully');
                       $this->session->set_userdata('error_cls','success');
					   
					}
                    else
                    {
                        
					   $this->session->set_userdata('error_msg','Error occurred, Try again...');
                       $this->session->set_userdata('error_cls','danger');
                    }
                    redirect(base_url().'organisation_acc?ch=org_profile');
					
				  }
			   }
             
             
             
             
             
				$this->load->view('organisation/update_organisation_profile');
			}else
			if($_GET['ch']=="change_pass")
			{
				 if(isset($_POST['change_password']))
			     {
				
				
				   $this->form_validation->set_rules('current_password','current password','required|xss_clean');
				   $this->form_validation->set_rules('new_password','new password','required|xss_clean');
				   $this->form_validation->set_rules('rnew_password','re-enter password','matches[new_password]|required|xss_clean');
				
				  if($this->form_validation->run())
			  	   { 
				 
					
                    $this->load->model('site_model');
					$result=$this->site_model->change_password("o_email","o_password","organisation");
					
					 
				   }
			    }
                
                $this->load->view('organisation/update_password');
			}
			else
			if($_GET['ch']=="logout")
			{
				$this->session->sess_destroy();
				redirect(base_url().'site/');
			}	
	}else
	{
?>				
					<h3> Welcome <span style="color:#e8ae17; text-transform: uppercase"><?=$this->session->userdata('name')?>,</span></h3>
					<strong>Email : </strong> <?=$this->session->userdata('username')?><br/>
					
					<?php
						$qq=$this->db->query("select * from organisation where o_email = '".$this->session->userdata('username')."'")->row();
						if($qq)
						{
?>
							<strong>Address : </strong><?=$qq->o_address?><br/>
							<strong>State : </strong><?=$qq->o_state?><br/>
							<strong>City : </strong><?=$qq->o_city?>-<?=$qq->o_pin_code?><br/>
							
<?php							
						}
	}
?>					
			</div>
			</div>
		</div>
	</div>
</div>