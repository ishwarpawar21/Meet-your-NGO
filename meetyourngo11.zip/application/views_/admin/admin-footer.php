<!-- END Main Content -->
                <footer>
                    <p><?php echo date('Y'); ?> © Coupon.com</p>
                </footer>
                <a id="btn-scrollup" class="btn btn-circle btn-lg" href="#"><i class="fa fa-chevron-up"></i></a>
            </div>
            <!-- END Content -->
        </div>
        <!-- END Container -->
        <!--basic scripts-->
        <!--<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="assets/jquery/jquery-2.0.3.min.js"><\/script>')</script>-->
        <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>assets/jquery-slimscroll/jquery.slimscroll.min.js"></script>
        <script src="<?php echo base_url();?>assets/jquery-cookie/jquery.cookie.js"></script>
        <!--page specific plugin scripts-->
        <script src="<?php echo base_url();?>assets/flot/jquery.flot.js"></script>
        <script src="<?php echo base_url();?>assets/flot/jquery.flot.resize.js"></script>
        <script src="<?php echo base_url();?>assets/flot/jquery.flot.pie.js"></script>
        <script src="<?php echo base_url();?>assets/flot/jquery.flot.stack.js"></script>
        <script src="<?php echo base_url();?>assets/flot/jquery.flot.crosshair.js"></script>
        <script src="<?php echo base_url();?>assets/flot/jquery.flot.tooltip.min.js"></script>
        <script src="<?php echo base_url();?>assets/sparkline/jquery.sparkline.min.js"></script>
        <!--page specific plugin scripts-->
        <script src="<?php echo base_url();?>assets/bootstrap-wizard/jquery.bootstrap.wizard.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/jquery-validation/dist/jquery.validate.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/jquery-validation/dist/additional-methods.min.js"></script>
        <!--flaty scripts-->
        <script src="<?php echo base_url();?>js/flaty.js"></script>
        <script src="<?php echo base_url();?>js/flaty-demo-codes.js"></script>
 </body>
</html>