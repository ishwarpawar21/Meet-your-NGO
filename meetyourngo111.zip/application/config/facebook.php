<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['appID']	= '1512439695640622';
$config['appSecret']	= '88643a72576748a958c55c921ad3e8f1';











/* End of file facebook.php */



/* Location: ./application/config/facebook.php */



