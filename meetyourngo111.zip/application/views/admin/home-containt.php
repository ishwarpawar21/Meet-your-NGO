<!-- BEGIN Page Title -->

<div class="page-title">

    <div style="clear:both !important;">

        <h1><i class="fa fa-pencil-square"></i>Home containt</h1>



    </div>

</div>

<!-- END Page Title -->

<!-- BEGIN Breadcrumb -->

<div id="breadcrumbs">

    <ul class="breadcrumb">

        <li>

            <i class="fa fa-home"></i>

            <a href="<?php echo base_url().'superadmin/admin/dashboard/'; ?>">Home</a>

            <span class="divider"><i class="fa fa-angle-right"></i></span>

        </li>

        <li>

        	<a href="<?php echo base_url().'superadmin/'; ?>">Home containt</a>

            <span class="divider"><i class="fa fa-angle-right"></i></span>

        </li>

        <li class="active">Home containt</li>

    </ul>

</div>



<!-- END Breadcrumb -->

<!-- BEGIN Main Content -->

<div class="row">

    <div class="col-md-12">

        <div class="box">

            <div class="box-title">

                <h3><i class="fa fa-bars"></i>Home containt</h3>

                <div class="box-tool">

                    <a  class="show-tooltip" href="<?php echo base_url().'superadmin/';?>" title="Back"><i class="fa fa-chevron-up"></i></a>

                   <!-- <a data-action="close" href="#"><i class="fa fa-times"></i></a>-->

                </div>

            </div>

            <div class="box-content">

              <form class="form-horizontal" id="validation-form" method="post" enctype="multipart/form-data">


                 <div class="form-group">

                      <label class="col-sm-3 col-lg-2 control-label">Select heading </label>

                      <div class="col-sm-6 controls">

                         <select name="heading_option" class="form-control" onchange="setheading(this)">
                         <option></option>
                         <option>Heading 1</option>
                         <option>Heading 2</option>
                         <option>Heading 3</option>
                         <option>Heading 4</option>
                       
                         </select>

                         <?php echo form_error('heading_option'); ?>

                         <div class="error_msg" id="error_faq_ques" style="display:none;"></div>

                      </div>

                   </div>


 <div class="form-group">

                      <?php 
                       
                        $row=$this->db->query("select * from home_page_table where id=1")->row(); ?>
                      <label class="col-sm-3 col-lg-2 control-label">Heading </label>

                      <div class="col-sm-6 controls">

                       <input type="text" class="form-control"	name="heading_name" id="heading_name" placeholder="Heading" value="<?=$row->containt_data?>" data-rule-required="true" />
                       
                         <option>

                         <?php echo form_error('heading_option'); ?>

                         <div class="error_msg" id="error_faq_ques" style="display:none;"></div>

                      </div>

                   </div>
                   <script type="text/javascript">
		
    function setheading(element){
    
	 $.ajax({url: "<?php echo base_url(); ?>" + "ajax_post_controller/searchopt/set_heading?set_heading="+element.value,
             success: function(output) {
              
                $('#test').html(output);
            },
          error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status + " "+ thrownError);
          }});

	//alert($this->session->userdata('locality_data'));
  
}

</script>


             
                     <div class="form-group">

                      <label class="col-sm-3 col-lg-2 control-label">Heading sub line: </label>

                      <div class="col-sm-6 controls">

                         <input type="text" class="form-control"	name="heading_name_sub" id="heading_name_sub" placeholder="Sub heading" value="<?=$row->sub_containt?>" data-rule-required="true" />

                         <?php echo form_error('heading_name_sub'); ?>

                         <div class="error_msg" id="error_faq_ques" style="display:none;"></div>

                      </div>
                     

                   </div>

               

                  <div class="form-group">

                     <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2">

                        <input type="submit" value="Add" class="btn btn-primary" name="btn_update_heading" id="btn_update_heading" onclick="return checkCheckBoxes(this.form);">

                         <button type="reset" class="btn">Cancel</button>

                   </div>

                   </div>

               </form>

            </div>
            
             <div class="clearfix"></div>
               
                
                
                
            
            
            
            
            
            
           

    </div>
    
    
      <div class="box">

            <div class="box-title">

                <h3><i class="fa fa-bars"></i>Upcoming event</h3>

                <div class="box-tool">

                    <a  class="show-tooltip" href="<?php echo base_url().'superadmin/';?>" title="Back"><i class="fa fa-chevron-up"></i></a>

                   <!-- <a data-action="close" href="#"><i class="fa fa-times"></i></a>-->

                </div>

            </div>

            <div class="box-content">

              <form class="form-horizontal" id="validation-form" method="post" enctype="multipart/form-data">


                     <div class="form-group">

                      <label class="col-sm-3 col-lg-2 control-label">Upcoming event: </label>

                     <div class="col-sm-9 col-lg-10 controls">
                                                   <textarea class="form-control col-md-12 ckeditor" name="upcoming_event"  id="upcoming_event" rows="6" data-rule-required="true"></textarea>
                                                </div>
                     

                   </div>

               
                 
                  <div class="form-group">

                     <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2">

                        <input type="submit" value="Update" class="btn btn-primary" name="btn_update_upcoming" id="btn_update_upcoming" onclick="return checkCheckBoxes(this.form);">

                         <button type="reset" class="btn">Cancel</button>

                   </div>

                   </div>

               </form>

            </div>
            
             <div class="clearfix"></div>
               
               <div class="box">

            <div class="box-title">

                <h3><i class="fa fa-bars"></i>Footer</h3>

                <div class="box-tool">

                    <a  class="show-tooltip" href="<?php echo base_url().'superadmin/';?>" title="Back"><i class="fa fa-chevron-up"></i></a>

                   <!-- <a data-action="close" href="#"><i class="fa fa-times"></i></a>-->

                </div>

            </div>

            <div class="box-content">

              <form class="form-horizontal" id="validation-form" method="post" enctype="multipart/form-data">

  <div class="form-group">

                      <label class="col-sm-3 col-lg-2 control-label">Select footer containt </label>

                      <div class="col-sm-6 controls">

                         <select name="footer_cotaint" class="form-control">
                         <option>Containt 1</option>
                         <option>Containt 2</option>
                         <option>Containt 3</option>
                        
                       
                         </select>

                         <?php echo form_error('heading_option'); ?>

                         <div class="error_msg" id="error_faq_ques" style="display:none;"></div>

                      </div></div>
                      
                     <div class="form-group">

                      <label class="col-sm-3 col-lg-2 control-label">Heading </label>

                      <div class="col-sm-6 controls">

                       <input type="text" class="form-control"	name="footer_heading_name" id="footer_heading_name" placeholder="Heading" value="" data-rule-required="true" />
                       
                         <option>

                         <?php echo form_error('footer_heading_name'); ?>

                         <div class="error_msg" id="error_faq_ques" style="display:none;"></div>

                      </div>

                   </div>
                   
                    <div class="form-group">

                      <label class="col-sm-3 col-lg-2 control-label">Footer containt </label>

                      <div class="col-sm-6 controls">

                      <div class="col-sm-9 col-lg-10 controls">
                      <textarea class="form-control col-md-12 ckeditor" name="footer_containt"  id="footer_containt" rows="6" data-rule-required="true"></textarea>
                    </div>
                         <option>

                         <?php echo form_error('footer_containt'); ?>

                         <div class="error_msg" id="error_faq_ques" style="display:none;"></div>

                      </div>

                   </div>
                    
                   
                   <div class="form-group">

                     <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2">

                        <input type="submit" value="Update" class="btn btn-primary" name="btn_update_footer" id="btn_update_footer" onclick="return checkCheckBoxes(this.form);">

                         <button type="reset" class="btn">Cancel</button>

                   </div>

                   </div>

                   </div>

               </form>

            </div>  
                
                
            
            
            
            
            
            
           

    </div>
    <!-- END Main Content -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/ckeditor/ckeditor.js"></script> 
    
    
    
    
     
    
    

</div>

<!-- END Main Content -->

  


<!-- END Main Content -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/data-tables/bootstrap3/dataTables.bootstrap.css" />
<script type="text/javascript" src="<?php echo base_url(); ?>assets/data-tables/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/data-tables/bootstrap3/dataTables.bootstrap.js"></script>