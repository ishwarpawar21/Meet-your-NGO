<!-- content -->
<div class="container">
<div class="main">
	<div class="row content_top">
		<div class="col-md-9 content_left">
	<!-- start slider -->
    <div id="fwslider">
        <div class="slider_container">
            <div class="slide"> 
                <!-- Slide image -->
                    <img src="<?=base_url()?>../site_assets/images/slider1.jpg" class="img-responsive" alt=""/>
                <!-- /Slide image -->
            </div>
            <!-- /Duplicate to create more slides -->
            <div class="slide">
                <img src="<?=base_url()?>../site_assets/images/slider2.jpg" class="img-responsive" alt=""/>
            </div>
            <div class="slide">
                <img src="<?=base_url()?>../site_assets/images/slider3.jpg" class="img-responsive" alt=""/>
            </div>
            <!--/slide -->
        </div>
        <div class="timers"></div>
        <div class="slidePrev"><span></span></div>
        <div class="slideNext"><span></span></div>
    </div>

	<!-- end  slider -->
		</div>
		<div class="col-md-3 sidebar">
		<div class="grid_list">
			<a href="#"> 
				<div class="grid_text left">
					<h3><a href="#">Heading 1</a></h3>
					<p>This is sort description.</p>
				</div>
				<div class="clearfix"></div>
			</a>	
		</div>	
		
		<div class="grid_list">
			<a href="#"> 
				<div class="grid_text left">
					<h3><a href="#">Heading 2</a></h3>
					<p>This is sort description.</p>
				</div>
				<div class="clearfix"></div>
			</a>	
		</div>	
		
		<div class="grid_list">
			<a href="#"> 
				<div class="grid_text left">
					<h3><a href="#">Heading 3</a></h3>
					<p>This is sort description.</p>
				</div>
				<div class="clearfix"></div>
			</a>	
		</div>	 			
		 <div class="grid_list">
			<a href="#"> 
				<div class="grid_text left">
					<h3><a href="#">Heading 4</a></h3>
					<p>This is sort description.</p>
				</div>
				<div class="clearfix"></div>
			</a>	
		</div>					
		</div>
		<div class="clearfix"></div>
	</div>
	<!-- start content -->
	<div class="content">
 
		<div class="content_text">
			<h2><a>Volunteers</a></h2>
			 
		</div>
		<!-- grids_of_3 -->
		<div class="row grids">
		
			<div class="col-md-4 grid1">
					<div class="col-md-12" style="padding: 0">
					  <img src="<?=base_url()?>../site_assets/images/pic1.jpg" class="" alt="" style="float: left"/>
					  <h3>Volunteer I</h3>
					  <p>This is Sub heading. </p>
					</div>
					<div class="col-md-12">
						<p>This is description. This is description. This is description. This is description. This is description. This is description. </p>
						<div class="create_btn" style="float: none;margin-top: 10px">
								<a>Read More</a>
						</div>
					</div>
			</div>
			
			<div class="col-md-4 grid1">
					<div class="col-md-12" style="padding: 0">
					  <img src="<?=base_url()?>../site_assets/images/pic1.jpg" class="" alt="" style="float: left"/>
					  <h3>Volunteer II</h3>
					  <p>This is Sub heading. </p>
					</div>
					<div class="col-md-12">
						<p>This is description. This is description. This is description. This is description. This is description. This is description. </p>
						<div class="create_btn" style="float: none;margin-top: 10px">
								<a>Read More</a>
						</div>
					</div>
			</div>
			
			<div class="col-md-4 grid1">
					<div class="col-md-12" style="padding: 0">
					  <img src="<?=base_url()?>../site_assets/images/pic1.jpg" class="" alt="" style="float: left"/>
					  <h3>Volunteer III</h3>
					  <p>This is Sub heading. </p>
					</div>
					<div class="col-md-12">
						<p>This is description. This is description. This is description. This is description. This is description. This is description. </p>
						<div class="create_btn" style="float: none;margin-top: 10px">
								<a>Read More</a>
						</div>
					</div>
			</div>
			
			
			 
			 
		</div>
		<!-- end grids_of_3 -->
	</div>
	
	<div class="content" style="text-align: left">
		<div class="content_text">
			<h2 align="center"><a>Upcoming Events</a></h2>
			<p align="center">This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. </p>
		</div>
		
		<div class="row grids">
			<div class="col-md-4 grid1">
					<div class="col-md-12" style="padding: 0">
					  <img src="<?=base_url()?>../site_assets/images/icon4.png" class="" alt="" style="margin:0 10px; float: left"/>
					  <h3>Teaching Childrens</h3>
						<p>This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo.This is demo. This is demo. This is demo. This is demo. This is demo. </p>
					</div>
			</div>
			
			<div class="col-md-4 grid1">
					<div class="col-md-12" style="padding: 0">
					  <img src="<?=base_url()?>../site_assets/images/icon4.png" class="" alt="" style="margin:0 10px; float: left"/>
					  <h3>Teaching Childrens</h3>
						<p>This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo.This is demo. This is demo. This is demo. This is demo. This is demo. </p>
					</div>
			</div>
			
			<div class="col-md-4 grid1">
					<div class="col-md-12" style="padding: 0">
					  <img src="<?=base_url()?>../site_assets/images/icon4.png" class="" alt="" style="margin:0 10px; float: left"/>
					  <h3>Teaching Childrens</h3>
						<p>This is demo. This is demo. This is demo. This is demo. This is demo. This is demo. This is demo.This is demo. This is demo. This is demo. This is demo. This is demo. </p>
					</div>
			</div>
		</div>
		
		
	</div> <!-- end content -->
</div>
</div>