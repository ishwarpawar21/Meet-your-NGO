<div class="contain"> 
  <!--inner-->
  <div class="new-coupon-inner"> 
    <!--contain-left-->
    <div class="">
      <div class="co-pages">
        <div class="new-heading">
          <div class="new-heading-inner">
            <div class="inner-page-heading">
            <?php echo $pagedetail[0]['front_page_name'];?>
            </div>
            <div class="clr"></div>
          </div>
        </div>
        <div class="clr"></div>
      </div>
      <div class="co-pages" style=" padding-bottom:0px;"> 
        <!--main-box-->
        <div class="product-titme">
        <?php echo $pagedetail[0]['front_page_title'];?>
	    </div>
        <div class="product-desk">
       <?php echo $pagedetail[0]['front_page_description'];?> 
        </div>
        <!--main-box--> 
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
    <!--contain-left--> 
    <div class="clr"></div>
  </div>
  <!--inner--> 
</div>